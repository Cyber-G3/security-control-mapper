import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const require = createRequire(import.meta.url);
const { calculateCoverage } = require('../docs/coverage-engine.js');

const here = path.dirname(fileURLToPath(import.meta.url));
const dataset = JSON.parse(readFileSync(path.join(here, '../docs/data/mappings-v0.1.json'), 'utf-8'));
const fixtures = JSON.parse(readFileSync(path.join(here, 'fixtures/coverage-parity-fixtures.json'), 'utf-8'));

let failures = 0;
for (const fixture of fixtures) {
  try {
    const actual = calculateCoverage(dataset.records, fixture.observations);
    assert.deepEqual(actual, fixture.expected);
    console.log(`ok - ${fixture.name} (${actual.length} coverage results match Python engine)`);
  } catch (err) {
    failures += 1;
    console.error(`FAIL - ${fixture.name}`);
    console.error(err);
  }
}

if (failures > 0) {
  console.error(`\n${failures} coverage parity fixture(s) failed against the Python engine.`);
  process.exit(1);
}
console.log('\nAll coverage parity fixtures passed — JS engine matches src/control_mapper/coverage.py.');
