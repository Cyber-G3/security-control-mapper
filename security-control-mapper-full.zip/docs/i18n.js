/**
 * SpectraSec Security Control Mapper — EN/ES translation for static UI text.
 *
 * Scope: page chrome (hero, pipeline, overview, coverage checker, explorer
 * labels). Does NOT translate mapping dataset content (framework names,
 * reference IDs, titles, relevance text, evidence items) — those mirror the
 * official English/EU terminology of ISO/IEC 27001, NIS2, ENS and SOC 2
 * regardless of UI language, and translating them without domain review
 * risks changing their meaning.
 */
const SCM_LANG_KEY = 'spectrasec-scm-lang';

const SCM_I18N = {
  en: {
    'hero.eyebrow': 'SpectraSec Open Source',
    'hero.lead': 'Explore how technical GitHub security findings relate to ISO/IEC 27001:2022, NIS2, ENS and SOC 2 supporting references — deterministic, versioned, no LLM at runtime.',
    'hero.linkOverview': 'Dataset overview',
    'hero.linkCoverage': 'Run a coverage check',
    'hero.linkRepo': 'Source repository',
    'pipeline.kicker': 'SpectraSec toolchain',
    'pipeline.title': 'Where this fits',
    'pipeline.step1Title': 'Security Evidence Collector',
    'pipeline.step1Desc': 'Gathers normalized PASS/FAIL/UNKNOWN checks from GitHub',
    'pipeline.step2Title': 'Security Control Mapper',
    'pipeline.step2Desc': 'This tool — maps findings to framework references and evidence coverage',
    'pipeline.step3Title': 'Vulnerability Risk Prioritizer',
    'pipeline.step3Desc': 'Prioritizes CVEs and rolls results into an executive GRC dashboard',
    'pipeline.link': 'See the Vulnerability Risk Prioritizer →',
    'overview.kicker': 'Dataset overview',
    'overview.title': 'Mapping coverage',
    'overview.status': 'Every reference below comes straight from mappings-v0.1.json — the same dataset the CLI and coverage engine use. Nothing here is duplicated or hand-typed.',
    'overview.kpiFindings': 'Findings mapped',
    'overview.kpiRefs': 'Framework references',
    'overview.kpiFrameworks': 'Frameworks covered',
    'overview.kpiVersion': 'Dataset version',
    'overview.byFramework': 'By framework',
    'overview.refsPerFramework': 'References per framework',
    'overview.byConfidence': 'By confidence',
    'overview.refConfidence': 'Reference confidence',
    'overview.explainerSummary': 'What do DIRECT / SUPPORTING / CONTEXTUAL mean?',
    'overview.explainDirect': 'The finding maps to a control requirement with a clear, unambiguous relationship.',
    'overview.explainSupporting': 'The finding provides meaningful supporting evidence for the control, without being a full or exclusive implementation of it.',
    'overview.explainContextual': 'The finding is potentially relevant depending on organizational scope, system category or applicability — confirm before relying on it.',
    'coverage.kicker': 'Live evidence check',
    'coverage.title': 'Run a coverage check',
    'coverage.status': 'Paste the normalized GitHub check observations from your Security Evidence Collector output (one JSON array combining your normalized/github/*.json files) to see SUPPORTED / PARTIAL / GAP / UNKNOWN status per framework reference — computed entirely in your browser, nothing is uploaded.',
    'coverage.run': 'Run coverage check',
    'coverage.loadSample': 'Load sample data',
    'coverage.accepted': 'Accepted status values per observation: PASS, FAIL, UNKNOWN, ERROR.',
    'explorer.kicker': 'Explorer',
    'explorer.title': 'Look up a finding',
    'explorer.categoryIntro': 'Findings are grouped by the area of your repository they affect. Click a category to jump to it, or search across all of them.',
    'explorer.searchPlaceholder': 'Search finding, framework or reference…',
    'explorer.allFrameworks': 'All frameworks',
    'explorer.notSure': 'Not sure where to start? Try one of these:',
    'explorer.presetNis2': 'Everything relevant to NIS2',
    'explorer.presetDirect': 'Strongest mappings only (Direct)',
    'explorer.presetPreventive': 'Preventive controls',
    'explorer.presetSecrets': 'Secrets & credentials',
    'explorer.presetEnsOrg': 'ENS — organizational framework',
    'explorer.allThemes': 'All control families',
    'explorer.themeHelp': "Control family groups each framework reference by its own official structure — ISO 27001 Annex A themes, ENS org/mp/op measures, SOC 2 Trust Services categories.",
    'explorer.allConfidence': 'All confidence levels',
    'explorer.allControlTypes': 'All control types',
    'explorer.exportCsv': 'Export CSV',
    'explorer.exportJson': 'Export JSON',
    'explorer.notice': 'Mappings indicate potential relevance only. They do not establish compliance, certification, legal applicability or framework equivalence.',
    'footer.disclaimer': "Framework references are supporting indicators derived from technical findings, not compliance conclusions. Confirm applicability and scope with the relevant standard and your organization's compliance function.",
    'lang.toggle': 'ES',
  },
  es: {
    'hero.eyebrow': 'Código abierto de SpectraSec',
    'hero.lead': 'Explora cómo los hallazgos técnicos de seguridad en GitHub se relacionan con referencias de apoyo de ISO/IEC 27001:2022, NIS2, ENS y SOC 2 — determinista, versionado, sin LLM en tiempo de ejecución.',
    'hero.linkOverview': 'Resumen del dataset',
    'hero.linkCoverage': 'Ejecutar una verificación de cobertura',
    'hero.linkRepo': 'Repositorio del código',
    'pipeline.kicker': 'Suite de herramientas SpectraSec',
    'pipeline.title': 'Dónde encaja esta herramienta',
    'pipeline.step1Title': 'Security Evidence Collector',
    'pipeline.step1Desc': 'Recopila comprobaciones normalizadas PASS/FAIL/UNKNOWN desde GitHub',
    'pipeline.step2Title': 'Security Control Mapper',
    'pipeline.step2Desc': 'Esta herramienta — mapea hallazgos a referencias normativas y cobertura de evidencia',
    'pipeline.step3Title': 'Vulnerability Risk Prioritizer',
    'pipeline.step3Desc': 'Prioriza CVEs y agrega los resultados en un panel ejecutivo GRC',
    'pipeline.link': 'Ver el Vulnerability Risk Prioritizer →',
    'overview.kicker': 'Resumen del dataset',
    'overview.title': 'Cobertura de mapeos',
    'overview.status': 'Cada referencia proviene directamente de mappings-v0.1.json — el mismo dataset que usan el CLI y el motor de cobertura. Nada aquí está duplicado ni escrito a mano.',
    'overview.kpiFindings': 'Hallazgos mapeados',
    'overview.kpiRefs': 'Referencias normativas',
    'overview.kpiFrameworks': 'Marcos normativos cubiertos',
    'overview.kpiVersion': 'Versión del dataset',
    'overview.byFramework': 'Por marco normativo',
    'overview.refsPerFramework': 'Referencias por marco normativo',
    'overview.byConfidence': 'Por nivel de confianza',
    'overview.refConfidence': 'Confianza de las referencias',
    'overview.explainerSummary': '¿Qué significan DIRECT / SUPPORTING / CONTEXTUAL?',
    'overview.explainDirect': 'El hallazgo se corresponde con un requisito de control con una relación clara e inequívoca.',
    'overview.explainSupporting': 'El hallazgo aporta evidencia de apoyo relevante para el control, sin constituir una implementación completa o exclusiva del mismo.',
    'overview.explainContextual': 'El hallazgo es potencialmente relevante según el alcance organizativo, la categoría del sistema o la aplicabilidad — confírmalo antes de basarte en él.',
    'coverage.kicker': 'Verificación de evidencia en vivo',
    'coverage.title': 'Ejecutar una verificación de cobertura',
    'coverage.status': 'Pega las observaciones normalizadas de GitHub generadas por tu Security Evidence Collector (un array JSON combinando tus archivos normalized/github/*.json) para ver el estado SUPPORTED / PARTIAL / GAP / UNKNOWN por referencia normativa — calculado enteramente en tu navegador, no se sube nada.',
    'coverage.run': 'Ejecutar verificación',
    'coverage.loadSample': 'Cargar datos de ejemplo',
    'coverage.accepted': 'Valores de estado aceptados por observación: PASS, FAIL, UNKNOWN, ERROR.',
    'explorer.kicker': 'Explorador',
    'explorer.title': 'Buscar un hallazgo',
    'explorer.categoryIntro': 'Los hallazgos están agrupados por el área de tu repositorio a la que afectan. Haz clic en una categoría para saltar a ella, o busca en todas a la vez.',
    'explorer.searchPlaceholder': 'Buscar hallazgo, marco normativo o referencia…',
    'explorer.allFrameworks': 'Todos los marcos normativos',
    'explorer.notSure': '¿No sabes por dónde empezar? Prueba uno de estos:',
    'explorer.presetNis2': 'Todo lo relevante para NIS2',
    'explorer.presetDirect': 'Solo mapeos más fuertes (Direct)',
    'explorer.presetPreventive': 'Controles preventivos',
    'explorer.presetSecrets': 'Secretos y credenciales',
    'explorer.presetEnsOrg': 'ENS — marco organizativo',
    'explorer.allThemes': 'Todas las familias de control',
    'explorer.themeHelp': 'La familia de control agrupa cada referencia normativa según la estructura oficial propia de cada marco — temas del Anexo A de ISO 27001, medidas org/mp/op de ENS, categorías de Trust Services de SOC 2.',
    'explorer.allConfidence': 'Todos los niveles de confianza',
    'explorer.allControlTypes': 'Todos los tipos de control',
    'explorer.exportCsv': 'Exportar CSV',
    'explorer.exportJson': 'Exportar JSON',
    'explorer.notice': 'Los mapeos indican relevancia potencial únicamente. No establecen cumplimiento, certificación, aplicabilidad legal ni equivalencia normativa.',
    'footer.disclaimer': 'Las referencias normativas son indicadores de apoyo derivados de hallazgos técnicos, no conclusiones de cumplimiento. Confirma la aplicabilidad y el alcance con la norma correspondiente y tu función de cumplimiento.',
    'lang.toggle': 'EN',
  },
};

function applyScmLang(lang) {
  const dict = SCM_I18N[lang] || SCM_I18N.en;
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    if (Object.hasOwn(dict, key)) el.textContent = dict[key];
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (Object.hasOwn(dict, key)) el.setAttribute('placeholder', dict[key]);
  });
  const toggle = document.getElementById('lang-toggle');
  if (toggle) toggle.textContent = dict['lang.toggle'];
  document.documentElement.setAttribute('lang', lang);
  localStorage.setItem(SCM_LANG_KEY, lang);
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    const saved = localStorage.getItem(SCM_LANG_KEY) || 'en';
    applyScmLang(saved);
    document.getElementById('lang-toggle')?.addEventListener('click', () => {
      const current = localStorage.getItem(SCM_LANG_KEY) || 'en';
      applyScmLang(current === 'en' ? 'es' : 'en');
    });
  });
}
