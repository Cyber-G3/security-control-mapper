/**
 * SpectraSec Security Control Mapper — interactive explorer.
 *
 * Loads ./data/mappings-v0.1.json, a verbatim copy of
 * src/control_mapper/data/mappings-v0.1.json (CI fails the build if the two
 * drift — see .github/workflows/ci.yml, "Docs data in sync with source
 * dataset"). Nothing in this file hand-duplicates mapping content.
 *
 * The coverage checker delegates to coverage-engine.js, a verified port of
 * src/control_mapper/coverage.py (parity checked against the live Python
 * engine — see scripts/coverage-parity.mjs).
 */
const CONFIDENCE_LABELS = { DIRECT: 'Direct', SUPPORTING: 'Supporting', CONTEXTUAL: 'Contextual' };
const CONFIDENCE_ORDER = ['DIRECT', 'SUPPORTING', 'CONTEXTUAL'];
const CONFIDENCE_CLASS = { DIRECT: 'badge-direct', SUPPORTING: 'badge-supporting', CONTEXTUAL: 'badge-contextual' };
const CONFIDENCE_COLOR = { DIRECT: 'var(--c-direct)', SUPPORTING: 'var(--c-supporting)', CONTEXTUAL: 'var(--c-contextual)' };
const STATUS_CLASS = { SUPPORTED: 'status-supported', PARTIAL: 'status-partial', GAP: 'status-gap', UNKNOWN: 'status-unknown' };

// UI-only grouping (not part of the source dataset — purely a navigation aid
// for site visitors, kept out of mappings-v0.1.json so it stays a pure copy
// of the source-of-truth dataset checked by CI).
const CATEGORY_ORDER = ['access-control', 'secrets', 'dependencies', 'cicd', 'governance'];
const CATEGORY_META = {
  'access-control': { label: 'Change & access control', description: 'Controls over who can change code and how those changes get reviewed and approved.' },
  secrets: { label: 'Secrets & credentials', description: 'Controls that stop credentials and secrets from leaking into the repository.' },
  dependencies: { label: 'Dependency & supply chain', description: 'Controls over how third-party dependency vulnerabilities are tracked and patched.' },
  cicd: { label: 'CI/CD & automation', description: 'Controls over what your pipelines are allowed to do, and with what privileges.' },
  governance: { label: 'Governance & lifecycle', description: 'Documentation and lifecycle signals an auditor expects to find at the repository level.' },
};
const FINDING_CATEGORY = {
  'branch-protection-disabled': 'access-control',
  'required-pr-reviews-disabled': 'access-control',
  'required-status-checks-disabled': 'access-control',
  'codeowners-missing': 'access-control',
  'secret-scanning-disabled': 'secrets',
  'push-protection-disabled': 'secrets',
  'dependabot-config-missing': 'dependencies',
  'dependabot-security-updates-disabled': 'dependencies',
  'actions-policy-broad': 'cicd',
  'actions-sha-pinning-disabled': 'cicd',
  'workflow-permissions-broad': 'cicd',
  'repository-archived': 'governance',
  'security-policy-missing': 'governance',
};
function categoryOf(findingType) {
  return FINDING_CATEGORY[findingType] || 'governance';
}

// Control-family taxonomy per reference, derived directly from each
// framework's own official reference-code structure (not invented):
//   ISO/IEC 27001:2022 Annex A themes: A.5 Organizational, A.6 People,
//     A.7 Physical, A.8 Technological.
//   ENS prefixes: org.* Marco organizativo, mp.* Medidas de protección,
//     op.* Medidas operacionales.
//   SOC 2 Trust Services Criteria categories: CC1..CC9.
//   NIS2: this dataset's references are all Article 21(2) security-measure
//     points, which don't carry an official sub-taxonomy, so they're
//     grouped as a single family.
const ISO_THEMES = { 5: 'Organizational (A.5)', 6: 'People (A.6)', 7: 'Physical (A.7)', 8: 'Technological (A.8)' };
const ENS_FAMILIES = { org: 'Marco organizativo (org)', mp: 'Medidas de protección (mp)', op: 'Medidas operacionales (op)' };
const SOC2_CATEGORIES = {
  1: 'Control Environment (CC1)', 2: 'Communication & Information (CC2)', 3: 'Risk Assessment (CC3)',
  4: 'Monitoring Activities (CC4)', 5: 'Control Activities (CC5)', 6: 'Logical & Physical Access (CC6)',
  7: 'System Operations (CC7)', 8: 'Change Management (CC8)', 9: 'Risk Mitigation (CC9)',
};

function themeOf(ref) {
  const fw = ref.framework, code = ref.reference;
  if (fw === 'ISO/IEC 27001:2022') {
    const m = code.match(/^A\.(\d+)/);
    const label = m ? ISO_THEMES[m[1]] : null;
    return { key: `iso::${m ? m[1] : 'other'}`, label: label || 'Other', framework: fw };
  }
  if (fw === 'ENS') {
    const prefix = code.split('.')[0];
    return { key: `ens::${prefix}`, label: ENS_FAMILIES[prefix] || 'Other', framework: fw };
  }
  if (fw === 'SOC 2') {
    const m = code.match(/^CC(\d)/);
    const label = m ? SOC2_CATEGORIES[m[1]] : null;
    return { key: `soc2::${m ? m[1] : 'other'}`, label: label || 'Other', framework: fw };
  }
  if (fw === 'NIS2') {
    return { key: 'nis2::article21', label: 'Article 21(2) security measures', framework: fw };
  }
  return { key: `${fw}::other`, label: 'Other', framework: fw };
}


// Second, independent classification axis: what kind of control this is,
// regardless of which repo area it touches. Also UI-only (not in the
// source dataset) — a widely used control taxonomy (preventive / detective
// / corrective / administrative), applied here for navigation only.
const CONTROL_TYPE_ORDER = ['preventive', 'detective', 'corrective', 'administrative'];
const CONTROL_TYPE_META = {
  preventive: { label: 'Preventive', description: 'Stops an unsafe change or exposure before it happens.' },
  detective: { label: 'Detective', description: 'Flags a problem that already exists so it can be found and reviewed.' },
  corrective: { label: 'Corrective', description: 'Automatically or procedurally fixes a known issue.' },
  administrative: { label: 'Administrative', description: 'Documentation, ownership and lifecycle decisions auditors expect to see.' },
};
const FINDING_CONTROL_TYPE = {
  'branch-protection-disabled': 'preventive',
  'required-pr-reviews-disabled': 'preventive',
  'required-status-checks-disabled': 'preventive',
  'codeowners-missing': 'administrative',
  'secret-scanning-disabled': 'detective',
  'push-protection-disabled': 'preventive',
  'dependabot-config-missing': 'detective',
  'dependabot-security-updates-disabled': 'corrective',
  'actions-policy-broad': 'preventive',
  'actions-sha-pinning-disabled': 'preventive',
  'workflow-permissions-broad': 'preventive',
  'repository-archived': 'administrative',
  'security-policy-missing': 'administrative',
};
function controlTypeOf(findingType) {
  return FINDING_CONTROL_TYPE[findingType] || 'administrative';
}



function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function ringSVG(counts, palette, size = 126, stroke = 16) {
  const entries = Object.entries(counts).filter(([, v]) => v > 0);
  const total = entries.reduce((a, [, v]) => a + v, 0);
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  let acc = 0;
  const segments = total
    ? entries.map(([k, v]) => {
        const dash = (v / total) * c, gap = c - dash, offset = -acc;
        acc += dash;
        return `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${palette[k] || '#122539'}" stroke-width="${stroke}" stroke-dasharray="${dash.toFixed(2)} ${gap.toFixed(2)}" stroke-dashoffset="${offset.toFixed(2)}"/>`;
      }).join('')
    : `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--line-soft)" stroke-width="${stroke}"/>`;
  return `<svg viewBox="0 0 ${size} ${size}" class="ring-svg" role="img" aria-label="Confidence distribution"><g transform="rotate(-90 ${size / 2} ${size / 2})">${segments}</g></svg><div class="ring-center"><strong>${total}</strong><span>refs</span></div>`;
}

let dataset = null;

async function loadDataset() {
  const res = await fetch('data/mappings-v0.1.json');
  if (!res.ok) throw new Error(`Failed to load dataset: ${res.status}`);
  return res.json();
}

function allReferences(records) {
  return records.flatMap((r) => r.references.map((ref) => ({ ...ref, finding: r.finding_type })));
}

function renderOverview(records) {
  const refs = allReferences(records);
  const frameworks = [...new Set(refs.map((r) => r.framework))].sort();
  document.getElementById('stat-findings').textContent = records.length;
  document.getElementById('stat-refs').textContent = refs.length;
  document.getElementById('stat-frameworks').textContent = frameworks.length;
  document.getElementById('stat-version').textContent = dataset.mapping_version || '—';

  const frameworkCounts = {};
  frameworks.forEach((f) => { frameworkCounts[f] = refs.filter((r) => r.framework === f).length; });
  const maxCount = Math.max(...Object.values(frameworkCounts), 1);
  document.getElementById('framework-bars').innerHTML = Object.entries(frameworkCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([fw, count]) => `<div class="bar-row"><span>${esc(fw)}</span><div class="bar-track"><i style="width:${(count / maxCount) * 100}%"></i></div><strong>${count}</strong></div>`)
    .join('');

  const confidenceCounts = { DIRECT: 0, SUPPORTING: 0, CONTEXTUAL: 0 };
  refs.forEach((r) => { if (confidenceCounts[r.confidence] !== undefined) confidenceCounts[r.confidence] += 1; });
  document.getElementById('confidence-ring').innerHTML = ringSVG(confidenceCounts, CONFIDENCE_COLOR);
  document.getElementById('confidence-bars').innerHTML = CONFIDENCE_ORDER
    .map((k) => `<div class="bar-row"><span><i class="legend-dot" style="background:${CONFIDENCE_COLOR[k]}"></i>${CONFIDENCE_LABELS[k]}</span><div class="bar-track"><i style="width:${refs.length ? (confidenceCounts[k] / refs.length) * 100 : 0}%;background:${CONFIDENCE_COLOR[k]}"></i></div><strong>${confidenceCounts[k]}</strong></div>`)
    .join('');

  const frameworkFilter = document.getElementById('framework-filter');
  const currentFrameworkValue = frameworkFilter.value;
  frameworkFilter.innerHTML = '<option value="" data-i18n="explorer.allFrameworks">All frameworks</option>' + frameworks.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join('');
  frameworkFilter.value = currentFrameworkValue;

  const controlTypeFilter = document.getElementById('control-type-filter');
  const currentControlTypeValue = controlTypeFilter.value;
  controlTypeFilter.innerHTML = '<option value="">All control types</option>' + CONTROL_TYPE_ORDER.map((c) => `<option value="${c}">${esc(CONTROL_TYPE_META[c].label)}</option>`).join('');
  controlTypeFilter.value = currentControlTypeValue;

  const themeFilter = document.getElementById('theme-filter');
  const currentThemeValue = themeFilter.value;
  const themesByFramework = new Map();
  refs.forEach((r) => {
    const t = themeOf(r);
    if (!themesByFramework.has(t.framework)) themesByFramework.set(t.framework, new Map());
    themesByFramework.get(t.framework).set(t.key, t.label);
  });
  themeFilter.innerHTML = '<option value="" data-i18n="explorer.allThemes">All control families</option>' +
    frameworks.filter((f) => themesByFramework.has(f)).map((f) => {
      const entries = [...themesByFramework.get(f).entries()].sort((a, b) => a[1].localeCompare(b[1]));
      return `<optgroup label="${esc(f)}">${entries.map(([key, label]) => `<option value="${esc(key)}">${esc(label)}</option>`).join('')}</optgroup>`;
    }).join('');
  themeFilter.value = currentThemeValue;

  renderCategoryChips(records);
}

function renderCategoryChips(records) {
  const counts = {};
  records.forEach((r) => { const c = categoryOf(r.finding_type); counts[c] = (counts[c] || 0) + 1; });
  const el = document.getElementById('category-chips');
  const chips = ['<button type="button" class="chip chip-active" data-category="">All</button>']
    .concat(CATEGORY_ORDER.filter((c) => counts[c]).map((c) => `<button type="button" class="chip" data-category="${c}">${esc(CATEGORY_META[c].label)} <span class="chip-count">${counts[c]}</span></button>`));
  el.innerHTML = chips.join('');
  el.querySelectorAll('.chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      el.querySelectorAll('.chip').forEach((b) => b.classList.remove('chip-active'));
      btn.classList.add('chip-active');
      categoryState.current = btn.dataset.category;
      render();
    });
  });
}

const categoryState = { current: '' };

function matchesFilters(record, { query, framework, category, confidence, controlType, theme }) {
  if (category && categoryOf(record.finding_type) !== category) return false;
  if (controlType && controlTypeOf(record.finding_type) !== controlType) return false;
  if (framework && !record.references.some((r) => r.framework === framework)) return false;
  if (confidence && !record.references.some((r) => r.confidence === confidence)) return false;
  if (theme && !record.references.some((r) => themeOf(r).key === theme)) return false;
  if (!query) return true;
  const q = query.toLowerCase();
  const hay = [record.title, record.finding_type, record.description, ...record.references.flatMap((r) => [r.framework, r.reference, r.title])]
    .filter(Boolean).join(' ').toLowerCase();
  return hay.includes(q);
}

function copyLink(findingType) {
  const url = `${location.origin}${location.pathname}#finding-${findingType}`;
  navigator.clipboard?.writeText(url).catch(() => {});
  return url;
}

function findingCard(record) {
  const refs = record.references
    .map((r) => `<article class="finding-card"><h3>${esc(r.framework)} ${esc(r.reference)}<span class="badge ${CONFIDENCE_CLASS[r.confidence] || ''}">${esc(CONFIDENCE_LABELS[r.confidence] || r.confidence)}</span></h3><p class="meta">${esc(r.title)} · <span class="theme-tag">${esc(themeOf(r).label)}</span></p><p class="relevance">${esc(r.relevance || '')}</p></article>`)
    .join('');
  const evidence = (record.evidence_needed || []).map((e) => `<li>${esc(e)}</li>`).join('');
  const ct = controlTypeOf(record.finding_type);
  return `
    <div class="result-head" id="finding-${esc(record.finding_type)}">
      <div>
        <span class="control-type-tag control-type-${ct}">${esc(CONTROL_TYPE_META[ct].label)}</span>
        <h2>${esc(record.title)}</h2>
        <span class="result-meta">${esc(record.description || '')}</span>
      </div>
      <button type="button" class="copy-link-btn" data-finding="${esc(record.finding_type)}" aria-label="Copy link to this finding">Copy link</button>
    </div>
    ${refs}
    <article class="finding-card"><h3>Evidence to review</h3><ul class="evidence-list">${evidence}</ul></article>
  `;
}

function currentFilters() {
  return {
    query: document.getElementById('search').value.trim(),
    framework: document.getElementById('framework-filter').value,
    confidence: document.getElementById('confidence-filter').value,
    controlType: document.getElementById('control-type-filter').value,
    theme: document.getElementById('theme-filter').value,
    category: categoryState.current,
  };
}

function currentMatches() {
  const filters = currentFilters();
  return dataset.records.filter((r) => matchesFilters(r, filters));
}

function render() {
  if (!dataset) return;
  const matched = currentMatches();
  const result = document.getElementById('result');
  document.getElementById('result-count').textContent = matched.length === dataset.records.length
    ? `Showing all ${matched.length} findings.`
    : `Showing ${matched.length} of ${dataset.records.length} findings.`;
  if (!matched.length) {
    result.innerHTML = '<div class="no-results">No findings match this search or filter.</div>';
    return;
  }
  const byCategory = new Map();
  matched.forEach((r) => {
    const c = categoryOf(r.finding_type);
    if (!byCategory.has(c)) byCategory.set(c, []);
    byCategory.get(c).push(r);
  });
  result.innerHTML = CATEGORY_ORDER
    .filter((c) => byCategory.has(c))
    .map((c) => `
      <div class="category-section">
        <p class="section-kicker">${esc(CATEGORY_META[c].label)}</p>
        <p class="category-desc">${esc(CATEGORY_META[c].description)}</p>
        ${byCategory.get(c).map(findingCard).join('<hr style="border:none;border-top:1px solid var(--line);margin:8px 0"/>')}
      </div>`)
    .join('');
  result.querySelectorAll('.copy-link-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      copyLink(btn.dataset.finding);
      const original = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = original; }, 1500);
    });
  });
}

function exportRows() {
  const rows = [];
  currentMatches().forEach((record) => {
    record.references.forEach((ref) => {
      rows.push({
        finding_type: record.finding_type,
        finding_title: record.title,
        framework: ref.framework,
        reference: ref.reference,
        reference_title: ref.title,
        confidence: ref.confidence,
        relevance: ref.relevance,
        evidence_needed: (record.evidence_needed || []).join(' | '),
      });
    });
  });
  return rows;
}

function downloadBlob(content, filename, type) {
  const blob = new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

function toCsv(rows) {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const escapeCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  return [headers.join(','), ...rows.map((r) => headers.map((h) => escapeCell(r[h])).join(','))].join('\n');
}

// --- Coverage checker (client-side, uses coverage-engine.js) ---
const SAMPLE_OBSERVATIONS = [
  { check_id: 'github.branch.protection', status: 'FAIL' },
  { check_id: 'github.branch.required_reviews', status: 'PASS' },
  { check_id: 'github.security.secret_scanning', status: 'PASS' },
  { check_id: 'github.security.push_protection', status: 'UNKNOWN' },
  { check_id: 'github.dependencies.dependabot_config', status: 'FAIL' },
  { check_id: 'github.governance.security_policy', status: 'PASS' },
];

function statusLabel(status) {
  return { SUPPORTED: 'Supported', PARTIAL: 'Partial', GAP: 'Gap', UNKNOWN: 'Unknown' }[status] || status;
}

function renderCoverageResults(results) {
  const el = document.getElementById('coverage-results');
  if (!results.length) {
    el.innerHTML = '<div class="no-results">No mapped check IDs matched your observations. Check that check_id values match the source_check_ids in the dataset (e.g. github.branch.protection).</div>';
    return;
  }
  const order = { GAP: 0, PARTIAL: 1, UNKNOWN: 2, SUPPORTED: 3 };
  const sorted = [...results].sort((a, b) => (order[a.status] ?? 9) - (order[b.status] ?? 9));
  el.innerHTML = sorted.map((r) => `
    <article class="finding-card coverage-card ${STATUS_CLASS[r.status] || ''}">
      <h3>${esc(r.framework)} ${esc(r.reference)}<span class="badge status-badge-${(r.status || '').toLowerCase()}">${esc(statusLabel(r.status))}</span><span class="badge ${CONFIDENCE_CLASS[r.confidence] || ''}">${esc(CONFIDENCE_LABELS[r.confidence] || r.confidence)}</span></h3>
      <p class="meta">${esc(r.title)}</p>
      ${r.supporting_checks?.length ? `<p class="relevance">Passing: ${r.supporting_checks.map(esc).join(', ')}</p>` : ''}
      ${r.failing_checks?.length ? `<p class="relevance">Failing: ${r.failing_checks.map(esc).join(', ')}</p>` : ''}
      ${r.unknown_checks?.length ? `<p class="relevance">Unverified: ${r.unknown_checks.map(esc).join(', ')}</p>` : ''}
      ${r.evidence_needed?.length ? `<ul class="evidence-list">${r.evidence_needed.map((e) => `<li>${esc(e)}</li>`).join('')}</ul>` : ''}
    </article>`).join('');
}

function runCoverageCheck() {
  const input = document.getElementById('coverage-input').value.trim();
  const errorEl = document.getElementById('coverage-error');
  errorEl.textContent = '';
  if (!input) { renderCoverageResults([]); return; }
  let observations;
  try {
    const parsed = JSON.parse(input);
    observations = Array.isArray(parsed) ? parsed : parsed.observations;
    if (!Array.isArray(observations)) throw new Error('Expected a JSON array (or {"observations":[...]})');
    observations.forEach((o, i) => {
      if (!o.check_id || !o.status) throw new Error(`Item ${i} is missing check_id or status`);
    });
  } catch (err) {
    errorEl.textContent = `Could not parse input: ${err.message}`;
    renderCoverageResults([]);
    return;
  }
  const results = window.SpectrasecCoverage.calculateCoverage(dataset.records, observations);
  renderCoverageResults(results);
}

document.addEventListener('DOMContentLoaded', async () => {
  try {
    dataset = await loadDataset();
  } catch (err) {
    document.getElementById('result').innerHTML = '<div class="no-results">Could not load the mapping dataset. Please reload the page.</div>';
    console.error(err);
    return;
  }
  renderOverview(dataset.records);
  render();

  document.getElementById('search').addEventListener('input', render);
  document.getElementById('framework-filter').addEventListener('change', render);
  document.getElementById('confidence-filter').addEventListener('change', render);
  document.getElementById('control-type-filter').addEventListener('change', render);
  document.getElementById('theme-filter').addEventListener('change', render);
  document.querySelectorAll('.preset-chip').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.getElementById('search').value = '';
      document.getElementById('framework-filter').value = btn.dataset.framework || '';
      document.getElementById('confidence-filter').value = btn.dataset.confidence || '';
      document.getElementById('control-type-filter').value = btn.dataset.controltype || '';
      document.getElementById('theme-filter').value = btn.dataset.theme || '';
      categoryState.current = btn.dataset.category || '';
      document.querySelectorAll('#category-chips .chip').forEach((c) => c.classList.toggle('chip-active', c.dataset.category === categoryState.current));
      render();
      document.getElementById('result')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
  document.getElementById('export-csv').addEventListener('click', () => downloadBlob(toCsv(exportRows()), 'security-control-mapper-export.csv', 'text/csv;charset=utf-8'));
  document.getElementById('export-json').addEventListener('click', () => downloadBlob(JSON.stringify(exportRows(), null, 2), 'security-control-mapper-export.json', 'application/json'));

  document.getElementById('run-coverage').addEventListener('click', runCoverageCheck);
  document.getElementById('load-sample').addEventListener('click', () => {
    document.getElementById('coverage-input').value = JSON.stringify(SAMPLE_OBSERVATIONS, null, 2);
    runCoverageCheck();
  });

  // Deep-link support: #finding-<finding_type> in the URL on first load
  const hash = decodeURIComponent(location.hash || '').replace(/^#finding-/, '');
  if (hash) {
    const record = dataset.records.find((r) => r.finding_type === hash);
    if (record) {
      document.getElementById('search').value = record.title;
      render();
      requestAnimationFrame(() => document.getElementById(`finding-${hash}`)?.scrollIntoView({ block: 'start' }));
    }
  }
});
