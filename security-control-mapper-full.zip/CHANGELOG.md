# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

### Added

- Second, independent filter axis — **control family** — derived directly from each framework's own official reference-code structure (not invented): ISO/IEC 27001:2022 Annex A themes (A.5 Organizational, A.6 People, A.7 Physical, A.8 Technological), ENS prefixes (org/mp/op), and SOC 2 Trust Services Criteria categories (CC1–CC9). Shown as a grouped `<select>` (by framework) and as a label on every reference card. UI-only classification, not added to the source dataset.

- Interactive GitHub Pages explorer (`docs/`), delivering roadmap item v0.4. Includes a dataset overview (findings/references/frameworks counts, references-per-framework bar chart, confidence-distribution ring chart) and a search + framework filter over all 13 mapped findings.
- Findings in the explorer are grouped into five navigable categories (change & access control, secrets & credentials, dependency & supply chain, CI/CD & automation, governance & lifecycle) with clickable filter chips and a one-line "why this matters" description per group — UI-only grouping, not part of the source dataset.
- Second, independent filter axis: control type (preventive / detective / corrective / administrative), shown as a tag on every finding card and selectable via a dedicated filter — also UI-only classification.
- Confidence-level filter (Direct / Supporting / Contextual), independent of the framework filter.
- "Not sure where to start?" preset shortcuts above the explorer (e.g. "Everything relevant to NIS2", "Strongest mappings only", "Preventive controls", "Secrets & credentials") that set several filters at once for a first-time visitor.
- Live, client-side coverage checker: paste normalized GitHub check observations and see SUPPORTED/PARTIAL/GAP/UNKNOWN status per framework reference, computed entirely in the browser via `docs/coverage-engine.js`, a verified port of `coverage.py` (parity checked in CI against the live Python engine — see `scripts/coverage-parity.mjs`).
- Inline explainer of DIRECT / SUPPORTING / CONTEXTUAL confidence levels on the dataset overview.
- Deep-link and "copy link" support per finding (`#finding-<finding_type>`).
- CSV/JSON export of the current filtered explorer view.
- Pipeline diagram linking Security Evidence Collector → Security Control Mapper → Vulnerability Risk Prioritizer.
- `docs/data/mappings-v0.1.json`: a verbatim copy of the source dataset, so the web explorer never hand-duplicates mapping content.
- CI step ("Docs data in sync with source dataset") that fails the build if `docs/data/mappings-v0.1.json` diverges from `src/control_mapper/data/mappings-v0.1.json`.
- CI step ("JavaScript coverage engine parity") that fails the build if `docs/coverage-engine.js` diverges from `src/control_mapper/coverage.py`'s actual output.
- Shared design tokens (Space Grotesk / JetBrains Mono, navy/paper palette) matching the Vulnerability Risk Prioritizer, for a consistent SpectraSec tool suite.
- EN/ES language toggle for the page chrome (not for dataset content — see `docs/i18n.js` header comment).
- Skip link, print stylesheet, and `aria-live` result region for accessibility.
- `.github/dependabot.yml` for GitHub Actions and pip dependency updates.
- `.github/PIN_ACTIONS.md`: documents how to SHA-pin this repo's own GitHub Actions (the repo's own dataset flags unpinned Actions as a finding — this repo's workflows aren't pinned yet either).

### Fixed

- `tests/test_engine.py` and `tests/test_batch.py` asserted `mapping_version == "0.2"` while the dataset had already moved to `"0.3"`; updated both to match the actual dataset version.

### Changed

- `docs/app.js` previously hardcoded 4 of the 13 mapped findings and would silently drift from the real dataset as it grew. It now fetches and renders the full dataset directly.

### Known issues (flagged, not fixed here)

- `coverage.py`'s `calculate_coverage`: an observation with `status: NOT_APPLICABLE` still creates a coverage bucket (it counts as "matched" against `source_check_ids`), but doesn't populate passes/fails/unknowns — so it falls through to the `else` branch and is reported as `SUPPORTED` with zero supporting evidence. Ported faithfully to `docs/coverage-engine.js` for parity rather than silently diverging from the Python engine; the web UI's documented accepted status values omit `NOT_APPLICABLE` to avoid surfacing it, but the underlying behavior should be reviewed in `coverage.py`.
- `ruff check .` (9 errors) and `mypy src` (29 errors) currently fail on `main`, unrelated to the changes in this entry — mostly in `coverage.py` and `cli.py` typing. Not addressed here since it's core engine code outside this pass's scope.
